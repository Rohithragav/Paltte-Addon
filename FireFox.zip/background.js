/*
Open a new tab, and load "my-page.html" into it.
*/
function getDomain(sts){
	if (sts=="ok")
   browser.tabs.update({url: "https://academicscc.vit.ac.in/student/home.asp"});
//return "https://www.google.co.in/?#q="+name+"&*";
}

function openMyPage(messages) {
getDomain(messages.sts);

//browser.tabs.update({url: domain});
/*
var gettingAllStorageItems = browser.storage.local.get(null);
gettingAllStorageItems.then((results) => {
    var noteKeys = Object.keys(results);

    for(noteKey of noteKeys) {
      var curValue = results["uname"];
		browser.tabs.update({url: "http://www.google.com/?#q="+curValue});
    }
}, onError);
var cerd = {};
cerd["login"]=true;
browser.storage.local.set(cerd);
*/
}

function onError(error) {
	  console.log(error);
}





chrome.runtime.onMessage.addListener(openMyPage);

