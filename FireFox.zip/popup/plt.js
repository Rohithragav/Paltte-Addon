
var red = document.getElementById('r');
red.addEventListener('input',r);

var grn = document.getElementById('g');
grn.addEventListener('input',g);

var blu = document.getElementById('b');
blu.addEventListener('input',b);

//	var gettingAllStorageItems = browser.storage.local.get(null);
//gettingAllStorageItems.then((results) => {
//    if (results["login"]==true) {}
//    	var cerd = {};
//cerd["uname"]=d;
//browser.storage.local.set(cerd);
    
//}, onError);
	
	//document.getElementById('data').innerHTML="hi";
	//alert( d+"");
	//chrome.runtime.sendMessage({"name": d});
//});
function r() {
   document.body.style.opacity = this.value;
   document.getElementById('clr').style.backgroundColor=getValue();
   document.getElementById('code').innerHTML=getValue();
   document.getElementById('hcode').innerHTML=rgbToHex(getValue());
}
function g() {
   document.body.style.opacity = this.value;
    document.getElementById('clr').style.backgroundColor=getValue();
       document.getElementById('code').innerHTML=getValue();
       document.getElementById('hcode').innerHTML=rgbToHex(getValue());
}
function b() {
   document.body.style.opacity = this.value;
    document.getElementById('clr').style.backgroundColor=getValue();
       document.getElementById('code').innerHTML=getValue();
       document.getElementById('hcode').innerHTML=rgbToHex(getValue());
}
function getValue() {
var g=document.getElementById('r').value;
var g1=document.getElementById('g').value;
var g2=document.getElementById('b').value;
return "rgb("+g+","+g1+","+g2+")";
}

function rgbToHex(color) {
    color = ""+ color;
    if (!color || color.indexOf("rgb") < 0) {
        return;
    }

    if (color.charAt(0) == "#") {
        return color;
    }

    var nums = /(.*?)rgb\((\d+),\s*(\d+),\s*(\d+)\)/i.exec(color),
        r = parseInt(nums[2], 10).toString(16),
        g = parseInt(nums[3], 10).toString(16),
        b = parseInt(nums[4], 10).toString(16);

    return "#"+ (
        (r.length == 1 ? "0"+ r : r) +
        (g.length == 1 ? "0"+ g : g) +
        (b.length == 1 ? "0"+ b : b)
    );
}